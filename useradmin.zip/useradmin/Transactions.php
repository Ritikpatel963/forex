<?php
include 'sidebar.php';
?>
<div class="col-12">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Transaction</h4>
            <div class="table-responsive">
                <table id="zero_config" class="table table-striped table-bordered no-wrap">
                    <thead>
                        <tr>
                            <th >Order ID</th>
                            <th >Type</th>
                            <th >Account</th>
                            <th >Amount</th>
                            <th >Transaction Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
include 'footer.php';
?>