<?php
include 'sidebar.php';
?>

<div class="col-12">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Pending Order</h4>
            <div class="table-responsive">
                <table id="zero_config" class="table table-striped table-bordered no-wrap">
                    <thead>
                        <tr>
                        <tr>
                            <th>Order ID</th>
                            <th>Trading Account</th>
                            <th>Type</th>
                            <th>Symbol</th>
                            <th>Volume</th>
                            <th>Price</th>
                            <th>Stop Loss</th>
                            <th>Take Profit</th>
                            <th>Trading Time</th>
                            <th>Comment</th>
                        </tr>

                        </tr>

                    </thead>
                    <tbody>
                        <tr>

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
include 'footer.php';
?>