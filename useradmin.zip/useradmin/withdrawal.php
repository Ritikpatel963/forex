<?php
include 'sidebar.php';
?>

<div class="col-12">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Trade History</h4>
            <div class="table-responsive">
                <table id="zero_config" class="table table-striped table-bordered no-wrap">
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Account</th>
                            <th>Withdrawal Method</th>
                            <th>Withdrawal Amount</th>
                            <th>Net Withdrawal Amount</th>
                            <th>Status</th>
                            <th>Created By</th>
                            <th>Submission Time</th>
                            <th>Actions</th>
                        </tr>


                    </thead>
                    <tbody>
                        <tr>

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
include 'footer.php';
?>